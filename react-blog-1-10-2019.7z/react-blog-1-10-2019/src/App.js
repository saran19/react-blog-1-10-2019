import React, { Component } from 'react';
import './App.css';
import Routes from './route.jsx';

class App extends Component {
  render() {
    return (

      <div  className="App">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  <script src="https://unpkg.com/babel-standalone@6/babel.min.js"></script> 
  <script type="text/babel" src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script type="text/babel" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
 
        <Routes /><br/> <br/>
      
      </div>
    );
  }
}

export default  App;

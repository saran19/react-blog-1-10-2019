
import React, { Component } from "react";
import axios from "axios";
import {CopyToClipboard} from "react-copy-to-clipboard";
import { FacebookShareButton, TwitterShareButton,WhatsappShareButton,FacebookIcon,TwitterIcon,WhatsappIcon} from "react-share";


class Results extends Component {
    constructor(props) {
      super(props);
       
      this.state = {
        id:String,
        arID :String,
        listDataArticle:[]
  
        }
        this.getresults = this.getresults.bind(this);
    
      };
      componentDidMount() {
        this.state.arID = this.props.match.params.id;
        this.setState({arID : this.state.arID});
        this.getresults();
      }
    
     async  getresults() {
      
   await axios.get("https://alphath.thehindu.co.in/app/getArticleByIds.json?articleIds="+this.state.arID+"").then(response=>{
        
        this.state.listDataArticle.push(response.data);
        this.setState({ listDataArticle: this.state.listDataArticle });
      })
  
    }

    render() {
  
      return (
        
<div className="container">
	<div className="blog-page-main">
	  <h1 className="blog-title-top">Blog</h1>
	</div>
	<div className="row">
  {this.state.listDataArticle.length>0?(
    <section>
      {this.state.listDataArticle[0].data.map((article,index)=>(
		<div className="blog-pg-block" key={article}>
			<div className="col-sm-12 col-xs-12 col-lg-12 col-md-12">
				<h3 className="blog-article-title">{article.ti}</h3>
					<div className="author-name-article"><span>{article.au}</span>&nbsp;|&nbsp;<span className="date-blog"> {article.pd}</span></div>


          <div className="item">
                <div className="share-alt"><div className="hidden-lg hidden-md visible-xs hidden-sm">
                <i className="fa fa-share-alt alt"> </i>
                </div></div> 
                
                <span className="pull-right shre-alts sample" ref={index}>
                  
                <div className="social-icon-blog" data-id="1"> 
            
                <FacebookShareButton
                  url={window.location.href}
                  quote={article.ti}
                  className="icon-button facebook">
                  <FacebookIcon
                    size={25}
                    round />
                  </FacebookShareButton>
                
                <TwitterShareButton
                  url={window.location.href}
                  title={article.ti}
                  className="icon-button twitter">
                  <TwitterIcon
                    size={25}
                    round />
                  </TwitterShareButton>

                  <WhatsappShareButton
                url={window.location.href}
                title={article.ti}
                separator=":: "
                className="icon-button whatsapp">
                <WhatsappIcon size={25} round />
                </WhatsappShareButton>

                <CopyToClipboard text={window.location.href}
              onCopy={() => this.setState({copied: true})}>
                  <a className="icon-button link"><i className="fa fa-link"></i><span></span></a>
                </CopyToClipboard>
                
               
            </div></span> 
            </div>


						<div className="blog-article-img hidden-xs hidden-sm visible-lg visible-md">
							<img src={article.me[0].im} data-src-template={article.me[0].im} alt="A view of Alfa Serene Apartments at Maradu, located on the banks of Kochi backwaters on May 14, 2019." title="A view of Alfa Serene Apartments at Maradu, located on the banks of Kochi backwaters on May 14, 2019." className="lead-img adaptive placeholder" />
						</div>
						<div className="blog-article-img  visible-xs visible-sm hidden-lg hidden-md">
							<img src={article.me[0].im}data-src-template={article.me[0].im} alt="" title="" className="lead-img adaptive placeholder" />
						</div>

            <div dangerouslySetInnerHTML={{__html: `${article.de}`}} />

						
					<div> 
			</div>
		</div>
		 </div>
    ))}
     </section>
    ):([])}
		</div>
	</div>

        
      );
    }
  
  }
  
  export default Results;

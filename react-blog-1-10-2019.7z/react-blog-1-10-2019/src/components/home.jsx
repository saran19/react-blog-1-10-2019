

import React, { Component } from "react";
import axios from "axios";
import ReactDOM from "react-dom";
import {CopyToClipboard} from "react-copy-to-clipboard";
import { FacebookShareButton, TwitterShareButton,WhatsappShareButton,FacebookIcon,TwitterIcon,WhatsappIcon} from "react-share";

  
  class Home extends Component {
    constructor(props) {
      super(props);
      this.state = {listData:[],datas:[]}
        this.get = this.get.bind(this);
        this.articleList=this.articleList.bind(this);
        this.setListData = this.setListData.bind(this);
        
      };
      
      componentDidMount() {
        this.get();
        
      }

     async  get() {
     
    await axios.get("https://alphath.thehindu.co.in/app/getArticleByIds.json?articleIds=10381744,11383111,10096911,10377598,10388221").then(response=>{ 
        
         this.state.listData = response.data.data;
        this.setState({ listData: this.state.listData});
      this.setListData();
      
      })
  
    }

    setListData(){
      for(var i=0;i<this.state.listData.length;i++){
        this.myref =React.createRef();
        this.state.datas.push(this.myref);
      }
      this.setState({ datas: this.state.datas});
    }

    articleList(id,desc){
        var description = desc.replace(/[^A-Z0-9]+/ig, "-");
        this.props.history.push("/article/"+id+"/"+description);
    }

    convertTitle(title){
      var title_article = title.replace(/[^A-Z0-9]+/ig, "-");
      return title_article;
    }
    convertDate(artDate){
      var pubDate = new Date(artDate);
      var strArray=["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      var d = pubDate.getDate();
      var m = strArray[pubDate.getMonth()];
      var y = pubDate.getFullYear();
      return (d <= 9 ? "0" + d : d) + " " + m + " " + y;

    }


    toggle(e,j){
     
      if(( ReactDOM.findDOMNode(e.current).style.display) === "none") {
     ReactDOM.findDOMNode(e.current).style.display="block";
    }else if(( ReactDOM.findDOMNode(e.current).style.display) === "")  {
      ReactDOM.findDOMNode(e.current).style.display="block";
    }else  {
      ReactDOM.findDOMNode(e.current).style.display="none";
    }
  
     for(var i=0;i<this.state.listData.length;i++){
       if(this.state.datas[i]!==e){
         ReactDOM.findDOMNode(this.state.datas[i].current).style.display="none";
       }
     }
     this.setState(this.state.datas);
   
    } 
      
  
    render() {
    

     return (

        <div className="container">
        <div className="blog-page-main">
          <h1 className="blog-title-top">Blog</h1>
        </div>
          <div className="row">
          {this.state.listData.length>0?(
            <section>
          {this.state.listData.map((article,index)=>(

              <div className="blog-pg-block" key={index}>
                <div className="col-sm-9 col-xs-9">
                  <h3 className="blog-title"> <a onClick={() => this.articleList(article.aid,article.ti)} >{article.ti}</a></h3>
                  <p className="blog-para hidden-xs">{article.le}</p>
                <div className="pull-left author-name"><span>{article.au} </span>  <span className="date-blog"> { this.convertDate(article.pd)} </span></div>
                
                <div className="item">
                <div className="share-alt"><div className="hidden-lg hidden-md visible-xs hidden-sm">
               <a  ref={this.state.datas[index]} onClick={()=>this.toggle(this.state.datas[index],index)} ><i className="fa fa-share-alt alt"> </i></a>
                </div></div> 
                
                <span className="pull-right shre-alts sample" ref={this.state.datas[index]} >
                  
                <div className="social-icon-blog" data-id="1" > 
            
                <FacebookShareButton
                  url={window.location.href + "article/"+ article.aid +"/"+this.convertTitle(article.ti)}
                  quote={article.ti}
                  className="icon-button facebook">
                  <FacebookIcon
                    size={25}
                    round />
                  </FacebookShareButton>
                
                <TwitterShareButton
                  url={window.location.href + "article/"+ article.aid +"/"+this.convertTitle(article.ti)}
                  title={article.ti}
                  className="icon-button twitter">
                  <TwitterIcon
                    size={25}
                    round />
                  </TwitterShareButton>

                  <WhatsappShareButton
                url={window.location.href + "article/"+ article.aid +"/"+this.convertTitle(article.ti)}
                title={article.ti}
                separator=":: "
                className="icon-button whatsapp">
                <WhatsappIcon size={25} round />
                </WhatsappShareButton>

                <CopyToClipboard text={window.location.href + "article/"+ article.aid +"/"+this.convertTitle(article.ti)}
              onCopy={() => this.setState({copied: true})}>
                  <a className="icon-button link"><i className="fa fa-link"></i><span></span></a>
                </CopyToClipboard>
                
               
            </div></span> 
            </div>
                <div >
                
                
            </div>
            </div>
              
                <div className="col-sm-3 col-xs-3">
              <div className="blog-page-img">
              <div className="hidden-xs visible-lg visible-md hidden-sm">
              <a onClick={() => this.articleList(article.aid,article.ti)} ><img src={article.im_thumbnail} data-variant="LANDSCAPE" data-device-variant="LANDSCAPE~LANDSCAPE~SQUARE" data-src-template={article.im_thumbnail}  title={article.ti} className="media-object lazy adaptive placeholder" data-original={article.im_thumbnail} data-selected-width="215" /> </a>
              </div>
              <div className="hidden-lg visible-xs visible-sm hidden-md">
              <a onClick={() => this.articleList(article.aid,article.ti)} > <img src={article.im_thumbnail} title={article.ti} /> </a>
                </div>
              </div>
                </div>
              </div>

           ))}
           </section>
           ):([])}

          </div>
          </div>
        
      );  
      
     
    }
  
  }
  
  
  export default Home;
